<?php
include "sidebar.php"; // provides $conn (PDO)

// ========== Ensure sales table has required columns ==========
try {
    // Check if sales table exists
    $tableExists = $conn->query("SHOW TABLES LIKE 'sales'")->rowCount() > 0;
    if (!$tableExists) {
        // Create full table
        $conn->exec("CREATE TABLE sales (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            product_name VARCHAR(255) NOT NULL,
            quantity INT NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            total DECIMAL(10,2) NOT NULL,
            sale_date DATETIME NOT NULL
        )");
    } else {
        // Check and add price column
        $colPrice = $conn->query("SHOW COLUMNS FROM sales LIKE 'price'");
        if ($colPrice->rowCount() == 0) {
            $conn->exec("ALTER TABLE sales ADD COLUMN price DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER quantity");
        }
        // Check and add total column
        $colTotal = $conn->query("SHOW COLUMNS FROM sales LIKE 'total'");
        if ($colTotal->rowCount() == 0) {
            $conn->exec("ALTER TABLE sales ADD COLUMN total DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER price");
        }
    }
} catch (PDOException $e) {
    // Log error but continue (maybe we'll compute on the fly)
    error_log("Table setup error: " . $e->getMessage());
}

// Now, after ensuring columns, we can safely query
$hasPrice = false;
$hasTotal = false;
try {
    $hasPrice = $conn->query("SHOW COLUMNS FROM sales LIKE 'price'")->rowCount() > 0;
    $hasTotal = $conn->query("SHOW COLUMNS FROM sales LIKE 'total'")->rowCount() > 0;
} catch (PDOException $e) {
    // If table doesn't exist, we'll treat as missing
}

// ========== DATE FILTER ==========
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$where = "";
if ($start && $end) {
    $where = "WHERE DATE(sale_date) BETWEEN '$start' AND '$end'";
}

// ========== METRICS ==========
if ($hasTotal) {
    $totalSales = $conn->query("SELECT COALESCE(SUM(total), 0) as total FROM sales $where")->fetch(PDO::FETCH_ASSOC)['total'];
    $todaySales = $conn->query("SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE DATE(sale_date)=CURDATE()")->fetch(PDO::FETCH_ASSOC)['total'];
} else {
    // Fallback: compute total from price*quantity
    $totalSales = $conn->query("SELECT COALESCE(SUM(price * quantity), 0) as total FROM sales $where")->fetch(PDO::FETCH_ASSOC)['total'];
    $todaySales = $conn->query("SELECT COALESCE(SUM(price * quantity), 0) as total FROM sales WHERE DATE(sale_date)=CURDATE()")->fetch(PDO::FETCH_ASSOC)['total'];
}

$totalOrders = $conn->query("SELECT COUNT(*) as count FROM sales $where")->fetch(PDO::FETCH_ASSOC)['count'];

// ========== TOP PRODUCTS ==========
$topProducts = $conn->query("
    SELECT product_name, SUM(quantity) as qty 
    FROM sales 
    $where
    GROUP BY product_name 
    ORDER BY qty DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// ========== CHART DATA ==========
if ($hasTotal) {
    $chartData = $conn->query("
        SELECT DATE(sale_date) as day, SUM(total) as total 
        FROM sales 
        GROUP BY day 
        ORDER BY day ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $chartData = $conn->query("
        SELECT DATE(sale_date) as day, SUM(price * quantity) as total 
        FROM sales 
        GROUP BY day 
        ORDER BY day ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
}

// ========== RECENT SALES ==========
if ($hasPrice && $hasTotal) {
    $sales = $conn->query("SELECT id, product_name, quantity, price, total, sale_date FROM sales $where ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $sales = $conn->query("SELECT id, product_name, quantity, (price * quantity) as total, sale_date FROM sales $where ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAOVESA SyncPOS | Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: #0f141f;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        .container-fluid {
            background: #0f141f;
            padding: 0;
        }
        .card, .report-card {
            background: #1a1f2c;
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            transition: transform 0.2s;
        }
        .report-card {
            padding: 20px;
            color: #fff;
        }
        .report-card h6 {
            color: #e9c46a;
            font-size: 0.9rem;
            letter-spacing: 1px;
        }
        .report-card h3 {
            color: #fff;
            font-weight: 700;
        }
        .top-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #2a3448;
            color: #fff;
        }
        .top-item strong {
            color: #e9c46a;
        }
        .table {
            color: #fff;
        }
        .table thead {
            background: #0f141f;
            color: #e9c46a;
        }
        .table tbody tr {
            border-color: #2a3448;
        }
        .btn-primary {
            background: #e9c46a;
            border: none;
            color: #0a0f1a;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #ffd966;
        }
        .form-control {
            background: #252e42;
            border: 1px solid #e9c46a40;
            color: #fff;
        }
        .form-control:focus {
            background: #252e42;
            border-color: #e9c46a;
            box-shadow: none;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <h3 class="mb-4" style="color:#e9c46a; font-weight:700;">📊 Reports Dashboard</h3>

    <!-- FILTER -->
    <form method="get" class="row g-3 mb-4">
        <div class="col-md-3">
            <input type="date" name="start" class="form-control" value="<?= htmlspecialchars($start) ?>">
        </div>
        <div class="col-md-3">
            <input type="date" name="end" class="form-control" value="<?= htmlspecialchars($end) ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <!-- CARDS -->
    <div class="row g-4">
        <div class="col-md-4">
            <div class="report-card">
                <h6>Total Revenue</h6>
                <h3>Ksh <?= number_format($totalSales, 2) ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="report-card">
                <h6>Today's Sales</h6>
                <h3>Ksh <?= number_format($todaySales, 2) ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="report-card">
                <h6>Total Orders</h6>
                <h3><?= $totalOrders ?></h3>
            </div>
        </div>
    </div>

    <!-- CHART -->
    <div class="card p-4 mt-4">
        <h5 style="color:#e9c46a;">📈 Sales Trend</h5>
        <canvas id="salesChart"></canvas>
    </div>

    <!-- TOP PRODUCTS -->
    <div class="card p-4 mt-4">
        <h5 style="color:#e9c46a;">🏆 Top Selling Products</h5>
        <?php if (!empty($topProducts)): ?>
            <?php foreach ($topProducts as $tp): ?>
                <div class="top-item">
                    <span><?= htmlspecialchars($tp['product_name']) ?></span>
                    <strong><?= $tp['qty'] ?> sold</strong>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="color:#b9c3d4;">No data available.</p>
        <?php endif; ?>
    </div>

    <!-- SALES TABLE -->
    <div class="card p-4 mt-4">
        <h5 style="color:#e9c46a;">📋 Recent Sales</h5>
        <?php if (!empty($sales)): ?>
            <div class="table-responsive">
                <table class="table table-striped mt-3">
                    <thead>
                        <tr><th>Product</th><th>Qty</th><th>Total</th><th>Date</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sales as $s): ?>
                        <tr>
                            <td><?= htmlspecialchars($s['product_name']) ?></td>
                            <td><?= $s['quantity'] ?></td>
                            <td>Ksh <?= number_format($s['total'], 2) ?></td>
                            <td><?= $s['sale_date'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p style="color:#b9c3d4;">No sales recorded yet.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    const labels = <?= json_encode(array_column($chartData, 'day')) ?>;
    const data = <?= json_encode(array_column($chartData, 'total')) ?>;
    new Chart(document.getElementById('salesChart'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Revenue (Ksh)',
                data: data,
                borderColor: '#e9c46a',
                backgroundColor: 'rgba(233,196,106,0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { ticks: { callback: (v) => 'Ksh ' + v.toLocaleString() } }
            }
        }
    });
</script>
</body>
</html>