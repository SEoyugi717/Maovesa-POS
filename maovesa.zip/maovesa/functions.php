<?php
/**
 * MAOVESA SyncPOS – Core Functions
 * Requires config.php to be included before using these functions.
 */

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check if user is logged in. Redirect to login if not.
 */
function check_login() {
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit;
    }
}

/**
 * Get all products.
 * @return array
 */
function get_products() {
    global $conn;
    $stmt = $conn->query("SELECT * FROM products ORDER BY name");
    return $stmt->fetchAll();
}

/**
 * Add a sale (online) and update stock.
 * @param int $product_id
 * @param int $quantity
 * @return bool True on success, false if insufficient stock
 */
function add_sale($product_id, $quantity) {
    global $conn;
    // Get product info
    $stmt = $conn->prepare("SELECT name, price, quantity FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if (!$product || $product['quantity'] < $quantity) {
        return false;
    }

    $total = $product['price'] * $quantity;

    // Insert sale
    $stmt = $conn->prepare("INSERT INTO sales (product_id, product_name, quantity, price, total, sale_date) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$product_id, $product['name'], $quantity, $product['price'], $total]);

    // Update stock
    $stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
    $stmt->execute([$quantity, $product_id]);

    return true;
}

/**
 * Get low stock products (quantity <= low_stock_threshold).
 * @return array
 */
function low_stock_alerts() {
    global $conn;
    $stmt = $conn->query("SELECT * FROM products WHERE quantity <= low_stock_threshold ORDER BY quantity ASC");
    return $stmt->fetchAll();
}