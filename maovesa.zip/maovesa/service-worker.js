const CACHE_NAME = 'maovesa-cache-v1';
const urlsToCache = [
    '/index.php',
    '/sidebar.php',
    '/assets/css/custom.css',
    '/assets/js/app.js',
    // Add other static assets (CSS, JS, images) as needed
];

// Install event – cache app shell
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache))
    );
    self.skipWaiting();
});

// Activate – clean old caches
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys => Promise.all(
            keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
        ))
    );
    self.clients.claim();
});

// Fetch – serve from cache then network (offline fallback)
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => {
            return response || fetch(event.request);
        })
    );
});

// Background sync event (if supported)
self.addEventListener('sync', event => {
    if (event.tag === 'sync-sales') {
        event.waitUntil(syncSales());
    }
});

async function syncSales() {
    // This function will be called by the background sync.
    // It should call the same API endpoint as the manual sync.
    // For simplicity, we can fetch the API endpoint, but because
    // the service worker cannot directly access IndexedDB, we need
    // to use a client-side message or a dedicated sync endpoint.
    // A robust implementation would use a dedicated sync API.
    // Here we just notify clients to trigger sync.
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
        client.postMessage({ type: 'SYNC_SALES' });
    });
}