-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2026 at 09:46 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `maovesa`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `quantity`) VALUES
(1, 'Milk', 50.00, 20),
(2, 'Bread', 30.00, 15),
(3, 'Eggs', 10.00, 50),
(4, 'Milk 500ml', 50.00, 40),
(5, 'Milk 1L', 90.00, 30),
(6, 'Bread White', 60.00, 25),
(7, 'Bread Brown', 65.00, 20),
(8, 'Eggs Tray', 450.00, 15),
(9, 'Eggs 6 Pack', 90.00, 40),
(10, 'Sugar 1kg', 180.00, 35),
(11, 'Salt 500g', 50.00, 50),
(12, 'Cooking Oil 1L', 320.00, 20),
(13, 'Cooking Oil 500ml', 180.00, 25),
(14, 'Rice 1kg', 200.00, 30),
(15, 'Rice 2kg', 380.00, 20),
(16, 'Flour 2kg', 250.00, 25),
(17, 'Flour 1kg', 130.00, 30),
(18, 'Tea Leaves 250g', 120.00, 40),
(19, 'Coffee 100g', 150.00, 35),
(20, 'Soda Coca-Cola 500ml', 70.00, 50),
(21, 'Soda Fanta 500ml', 70.00, 50),
(22, 'Soda Sprite 500ml', 70.00, 50),
(23, 'Water 1L', 50.00, 60),
(24, 'Water 500ml', 30.00, 70),
(25, 'Biscuits Pack', 100.00, 40),
(26, 'Chocolate Bar', 120.00, 34),
(27, 'Toothpaste', 150.00, 30),
(28, 'Soap Bar', 80.00, 45),
(29, 'Shampoo Small', 200.00, 20),
(30, 'Detergent 500g', 180.00, 25),
(31, 'Detergent 1kg', 320.00, 20),
(32, 'Matches Box', 20.00, 99),
(33, 'Cereal 500g', 250.00, 14),
(34, 'Cereal 1kg', 450.00, 10),
(35, 'Yogurt 500ml', 120.00, 25),
(36, 'Yogurt 1L', 200.00, 18),
(37, 'Butter 250g', 180.00, 18),
(38, 'Cheese 200g', 220.00, 14);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `sale_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `product_name`, `quantity`, `price`, `total`, `sale_date`) VALUES
(1, 1, 'Milk', 2, 50.00, 100.00, '2026-03-19 13:37:15'),
(2, 2, 'Bread', 3, 30.00, 90.00, '2026-03-19 13:37:15'),
(3, 3, 'Eggs', 12, 10.00, 120.00, '2026-03-19 13:37:15'),
(4, 36, 'Yogurt 1L', 2, 200.00, 400.00, '2026-03-19 15:34:32'),
(5, 37, 'Butter 250g', 2, 180.00, 360.00, '2026-03-19 15:34:32'),
(6, 38, 'Cheese 200g', 1, 220.00, 220.00, '2026-03-19 15:34:32'),
(7, 32, 'Matches Box', 1, 20.00, 20.00, '2026-03-19 15:34:32'),
(8, 33, 'Cereal 500g', 1, 250.00, 250.00, '2026-03-19 15:34:32'),
(9, 26, 'Chocolate Bar', 1, 120.00, 120.00, '2026-03-19 15:34:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','attendant') DEFAULT 'attendant'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$EXAMPLEHASHADMIN', 'admin'),
(2, 'attendant', '$2y$10$EXAMPLEHASHATTENDANT', 'attendant'),
(3, 'odhyambo2005@gmail.com', '$2y$10$Qy/5seLUCjrCYcnGDmluy.S8SsFKR9qADdE2GsgQ33qV7Q2.VKXMK', 'attendant'),
(4, 'dhyambo2005@gmail.com', '$2y$10$n.KPPpfTUZpKfvYGzuQhmu0eN/Ir/6kbkfB5MFNQNsaThWjw2l7de', 'attendant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
