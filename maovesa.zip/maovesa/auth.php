<?php
session_start();
require_once "config.php";

// Logout handler
if(isset($_GET['logout'])){
    session_destroy();
    header("Location: login.php");
    exit();
}

// Helper for other pages
function check_login(){
    if(!isset($_SESSION['username'])){
        header("Location: login.php");
        exit();
    }
}
?>