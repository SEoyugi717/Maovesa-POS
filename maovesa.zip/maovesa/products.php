<?php
include "sidebar.php";

// ADD PRODUCT
if (isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $conn->prepare("INSERT INTO products (name, price, quantity) VALUES (?,?,?)")
        ->execute([$name, $price, $quantity]);
}

// DELETE PRODUCT
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM products WHERE id=$id");
}

// FETCH PRODUCTS
$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAOVESA SyncPOS | Products</title>
    <style>
        body {
            background: #0f141f;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        .container-fluid {
            background: #0f141f;
            padding: 0;
        }
        .card {
            background: #1a1f2c;
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        }
        .card h5, .card h3 {
            color: #e9c46a;
            font-weight: 600;
        }
        .form-control, .form-control:focus {
            background: #252e42;
            border: 1px solid #e9c46a40;
            color: #fff;
            border-radius: 12px;
        }
        .form-control::placeholder {
            color: #b9c3d4;
        }
        .btn-success {
            background: linear-gradient(135deg, #e9c46a, #ffd966);
            border: none;
            color: #0a0f1a;
            font-weight: 600;
            border-radius: 40px;
            transition: 0.2s;
        }
        .btn-success:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(233,196,106,0.3);
        }
        .btn-danger {
            background: #e06c4e;
            border: none;
            border-radius: 40px;
        }
        .btn-danger:hover {
            background: #c4452c;
        }

        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
        }
        .product-card {
            background: #1a1f2c;
            padding: 20px;
            border-radius: 20px;
            transition: 0.2s;
            border-bottom: 2px solid #e9c46a;
            color: #fff;
        }
        .product-card:hover {
            transform: translateY(-4px);
            background: #252e42;
        }
        .product-card h5 {
            color: #e9c46a;
            margin-bottom: 12px;
        }
        .product-card p {
            font-size: 1.2rem;
            font-weight: bold;
            margin: 0;
        }
        .stock {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            background: #2c5f8a;
            color: white;
        }
        .stock.low {
            background: #e06c4e;
        }
        .actions {
            margin-top: 15px;
            display: flex;
            justify-content: flex-end;
        }
        #search {
            background: #1a1f2c;
            border: 1px solid #e9c46a40;
            color: #fff;
            border-radius: 40px;
            padding: 12px 20px;
        }
        #search:focus {
            background: #252e42;
            border-color: #e9c46a;
            box-shadow: none;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <h3 class="mb-4" style="color:#e9c46a; font-weight:700;">📦 Product Management</h3>

    <!-- ADD PRODUCT -->
    <div class="card p-4 mb-4">
        <h5 class="mb-3">Add New Product</h5>
        <form method="post" class="row g-3">
            <div class="col-md-4">
                <input type="text" name="name" class="form-control" placeholder="Product Name" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="price" class="form-control" placeholder="Price (Ksh)" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="quantity" class="form-control" placeholder="Quantity" required>
            </div>
            <div class="col-md-2">
                <button type="submit" name="add_product" class="btn btn-success w-100">Add Product</button>
            </div>
        </form>
    </div>

    <!-- SEARCH -->
    <input type="text" id="search" class="form-control mb-4" placeholder="🔍 Search products...">

    <!-- PRODUCT GRID -->
    <div class="product-grid" id="productGrid">
        <?php foreach ($products as $p): ?>
            <div class="product-card" data-name="<?= strtolower(htmlspecialchars($p['name'])) ?>">
                <h5><?= htmlspecialchars($p['name']) ?></h5>
                <p>Ksh <?= number_format($p['price'], 2) ?></p>
                <span class="stock <?= $p['quantity'] <= 5 ? 'low' : '' ?>">
                    <?= $p['quantity'] <= 5 ? '⚠ Low Stock' : 'In Stock' ?> (<?= $p['quantity'] ?>)
                </span>
                <div class="actions">
                    <a href="?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this product?');">Delete</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
document.getElementById('search').addEventListener('keyup', function(){
    let value = this.value.toLowerCase();
    let cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
        let name = card.getAttribute('data-name');
        card.style.display = name.includes(value) ? 'block' : 'none';
    });
});
</script>
</body>
</html>