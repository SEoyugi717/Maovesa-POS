<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include unified database connection
require_once 'config.php';
require_once 'functions.php';   // contains check_login() and helpers

// Redirect if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAOVESA SyncPOS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <style>
        /* Sidebar - Luxury Dark Theme */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(145deg, #0a0f1a 0%, #141b2b 100%);
            padding-top: 25px;
            color: #fff;
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0,0,0,0.3);
            transition: all 0.3s;
        }

        /* Logo */
        .sidebar .logo {
            text-align: center;
            margin-bottom: 40px;
            padding: 0 15px;
        }
        .sidebar .logo h4 {
            font-weight: 700;
            font-size: 1.5rem;
            background: linear-gradient(135deg, #e9c46a, #ffd966);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin: 0;
            letter-spacing: -0.5px;
        }
        .sidebar .logo p {
            font-size: 0.7rem;
            color: #b9c3d4;
            margin-top: 5px;
            letter-spacing: 1px;
        }

        /* Navigation Links */
        .sidebar a {
            display: flex;
            align-items: center;
            gap: 14px;
            color: #b9c3d4;
            padding: 12px 20px;
            text-decoration: none;
            transition: all 0.2s;
            font-size: 15px;
            font-weight: 500;
            border-left: 3px solid transparent;
        }
        .sidebar a i {
            width: 24px;
            text-align: center;
            font-size: 1.1rem;
        }
        .sidebar a:hover {
            background: rgba(233,196,106,0.1);
            color: #e9c46a;
            border-left-color: #e9c46a;
            padding-left: 25px;
        }
        .sidebar a.active {
            background: rgba(233,196,106,0.15);
            color: #e9c46a;
            border-left-color: #e9c46a;
            font-weight: 600;
        }

        /* Content Area */
        .content {
            margin-left: 260px;
            padding: 20px 25px;
            background: #0f141f;
            min-height: 100vh;
        }

        /* Top Bar */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            background: #1a1f2c;
            padding: 12px 20px;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .topbar h5 {
            margin: 0;
            color: #e9c46a;
            font-weight: 600;
        }
        .logout-btn {
            background: linear-gradient(135deg, #e06c4e, #c4452c);
            border: none;
            padding: 6px 18px;
            color: white;
            border-radius: 40px;
            font-weight: 500;
            transition: 0.2s;
        }
        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(224,108,78,0.3);
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
                overflow-x: hidden;
            }
            .sidebar .logo h4, .sidebar .logo p {
                display: none;
            }
            .sidebar a span {
                display: none;
            }
            .sidebar a i {
                font-size: 1.3rem;
                margin: 0 auto;
            }
            .sidebar a {
                justify-content: center;
                padding: 12px 0;
            }
            .content {
                margin-left: 70px;
            }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="logo">
        <h4>✦ MAOVESA ✦</h4>
        <p>SyncPOS • Offline First</p>
    </div>

    <a href="index.php" class="<?= $current == 'index.php' ? 'active' : '' ?>">
        <i class="fas fa-chart-line"></i> <span>Dashboard</span>
    </a>
    <a href="sales.php" class="<?= $current == 'sales.php' ? 'active' : '' ?>">
        <i class="fas fa-cash-register"></i> <span>Sales Terminal</span>
    </a>
    <a href="products.php" class="<?= $current == 'products.php' ? 'active' : '' ?>">
        <i class="fas fa-box"></i> <span>Products</span>
    </a>
    <a href="reports.php" class="<?= $current == 'reports.php' ? 'active' : '' ?>">
        <i class="fas fa-chart-pie"></i> <span>Reports</span>
    </a>
    <a href="logout.php">
        <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
    </a>
</div>

<div class="content">
    <div class="topbar">
        <h5><i class="fas fa-store me-2"></i> MAOVESA SyncPOS</h5>
        <button class="logout-btn" onclick="window.location='logout.php'">
            <i class="fas fa-sign-out-alt me-1"></i> Logout
        </button>
    </div>
    <!-- Page-specific content will appear after this -->