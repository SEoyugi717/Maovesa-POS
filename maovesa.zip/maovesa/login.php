<?php
session_start();
include "config.php";

$error = "";

// Handle login
if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user && password_verify($password, $user['password'])){
        $_SESSION['username'] = $user['username'];
        $_SESSION['user'] = $user['username']; // optional
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doug Store Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e272e, #40739e);
            font-family: 'Segoe UI', sans-serif;
        }

        .login-card {
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(12px);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            width: 350px;
            color: white;
        }

        .login-card h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .form-control {
            background: rgba(255,255,255,0.1);
            border: none;
            color: white;
        }

        .form-control:focus {
            background: rgba(255,255,255,0.15);
            box-shadow: none;
            color: white;
        }

        .btn-login {
            background: #40739e;
            border: none;
            width: 100%;
            margin-top: 20px;
            padding: 10px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-login:hover {
            background: #2f3640;
        }

        .error-msg {
            color: #ff6b6b;
            text-align: center;
            margin-bottom: 15px;
        }

        .login-footer {
            margin-top: 15px;
            text-align: center;
            color: #dcdde1;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="login-card">
    <h2>Doug Store Login</h2>

    <?php if($error): ?>
        <div class="error-msg"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <input type="text" name="username" placeholder="Username" class="form-control" required>
        </div>
        <div class="mb-3">
            <input type="password" name="password" placeholder="Password" class="form-control" required>
        </div>
        <button type="submit" name="login" class="btn btn-login">Login</button>
    </form>

    <div class="login-footer">
        Don't have an account? <a href="register.php" style="color:#fff;">Register</a>
    </div>
</div>

</body>
</html>