<?php
// ============================================================
// MAOVESA SyncPOS – Dashboard (Offline‑first)
// ============================================================
require_once 'sidebar.php';   // starts session, checks login, outputs header & sidebar

// Helper: safe scalar query
function safeScalar($conn, $sql) {
    try {
        $stmt = $conn->query($sql);
        $val = $stmt->fetchColumn();
        return $val !== false ? $val : 0;
    } catch (PDOException $e) {
        error_log("SQL error: " . $e->getMessage());
        return 0;
    }
}

// KPIs
$total_sales_today = safeScalar($conn, "SELECT COUNT(*) FROM sales WHERE DATE(sale_date)=CURDATE()");
$total_revenue_today = safeScalar($conn, "SELECT SUM(total) FROM sales WHERE DATE(sale_date)=CURDATE()");
$total_products = safeScalar($conn, "SELECT COUNT(*) FROM products");
$low_stock = safeScalar($conn, "SELECT COUNT(*) FROM products WHERE quantity <= low_stock_threshold");

// Recent sales
$recent_sales = [];
try {
    $stmt = $conn->query("SELECT * FROM sales ORDER BY sale_date DESC LIMIT 5");
    $recent_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Recent sales error: " . $e->getMessage());
}

// Chart data: last 7 days
$labels = [];
$chart_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date_label = date('D', strtotime("-$i days"));
    $full_date = date('Y-m-d', strtotime("-$i days"));
    $sum = safeScalar($conn, "SELECT SUM(total) FROM sales WHERE DATE(sale_date)='$full_date'");
    $labels[] = $date_label;
    $chart_data[] = $sum ?: 0;
}
?>

<!-- Dashboard content starts here -->
<div class="container-fluid" style="padding:0;">
    <!-- OFFLINE BANNER -->
    <div id="offlineBanner" class="offline-banner" style="display: none;">
        ⚠️ You are offline. Sales will be saved locally and will sync automatically when connection is restored.
    </div>

    <!-- HEADER (already shown in topbar, but we keep the welcome text) -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h2 style="font-weight:700; color:#fff;">✨ MAOVESA SyncPOS Dashboard</h2>
        <div class="d-flex gap-3 align-items-center">
            <div class="sync-status">
                <span id="onlineStatusIcon">🟢</span> 
                <span id="onlineStatusText" style="color:#fff;">Online</span>
                <span id="pendingCountBadge" class="pending-badge ms-2" style="display: none;">0 pending</span>
                <button id="manualSyncBtn" class="sync-btn ms-2" title="Sync now">🔄</button>
            </div>
            <div class="welcome-text">
                👋 <?= htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>
            </div>
        </div>
    </div>

    <!-- KPI CARDS -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="kpi-card">
                <div><h6>📦 SALES TODAY</h6><h2><?= $total_sales_today ?></h2></div>
                <span>🛒</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card">
                <div><h6>💰 REVENUE</h6><h2>Ksh <?= number_format($total_revenue_today ?: 0,2) ?></h2></div>
                <span>💎</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card">
                <div><h6>📊 TOTAL PRODUCTS</h6><h2><?= $total_products ?></h2></div>
                <span>📋</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card">
                <div><h6>⚠️ LOW STOCK</h6><h2><?= $low_stock ?></h2></div>
                <span>🔔</span>
            </div>
        </div>
    </div>

    <!-- CHARTS -->
    <div class="row g-4 mb-4">
        <div class="col-lg-8">
            <div class="card p-4">
                <h5 class="mb-3">📈 Sales Trend (Last 7 Days)</h5>
                <canvas id="salesChart"></canvas>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card p-4">
                <h5 class="mb-3">📦 Stock Status</h5>
                <canvas id="stockChart"></canvas>
            </div>
        </div>
    </div>

    <!-- RECENT SALES TABLE -->
    <div class="card p-4">
        <h5 class="mb-3">🕒 Recent Sales</h5>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>ID</th><th>Product</th><th>Qty</th><th>Total</th><th>Date</th>\
                </thead>
                <tbody>
                    <?php foreach ($recent_sales as $sale): ?>
                    <tr>
                        <td><?= $sale['id'] ?></td>
                        <td><?= htmlspecialchars($sale['product_name']) ?></td>
                        <td><?= $sale['quantity'] ?></td>
                        <td>Ksh <?= number_format($sale['total'], 2) ?></td>
                        <td><?= date("d M Y H:i", strtotime($sale['sale_date'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// ========== IndexedDB Setup (Offline Queue) ==========
const DB_NAME = 'MaovesaSyncPOS';
const DB_VERSION = 1;
const STORE_NAME = 'pending_sales';
let db = null;

function openDB() {
    return new Promise((resolve, reject) => {
        if (db) return resolve(db);
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onerror = (event) => reject(event.target.error);
        request.onsuccess = (event) => {
            db = event.target.result;
            resolve(db);
        };
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
            }
        };
    });
}

async function addSaleToQueue(saleData) {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    await store.add({
        ...saleData,
        created_at: new Date().toISOString(),
        synced: false
    });
    await tx.complete;
    updatePendingCount();
}

async function getPendingSales() {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    return await store.getAll();
}

async function removeSaleFromQueue(id) {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    await store.delete(id);
    await tx.complete;
}

async function updatePendingCount() {
    const pending = await getPendingSales();
    const count = pending.length;
    const badge = document.getElementById('pendingCountBadge');
    if (count > 0) {
        badge.textContent = `${count} pending`;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }
}

// ========== Sync to Server (using new sync_sales.php) ==========
async function syncPendingSales() {
    const pending = await getPendingSales();
    if (pending.length === 0) return;

    const syncBtn = document.getElementById('manualSyncBtn');
    syncBtn.disabled = true;
    syncBtn.textContent = '⏳';

    try {
        const response = await fetch('sync_sales.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sales: pending })
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const result = await response.json();
        if (!result.success) {
            throw new Error(result.error || 'Sync failed');
        }
        if (result.errors && result.errors.length) {
            console.warn('Partial sync errors:', result.errors);
        }
        // Remove all pending sales
        for (const sale of pending) {
            await removeSaleFromQueue(sale.id);
        }
        if (result.synced_count > 0) {
            alert(`✅ ${result.synced_count} sales synced successfully!`);
            location.reload(); // Refresh to show updated stats
        }
    } catch (error) {
        console.error('Sync error:', error);
        alert(`Sync failed: ${error.message}. Will retry later.`);
    } finally {
        syncBtn.disabled = false;
        syncBtn.textContent = '🔄';
        updatePendingCount();
    }
}

// ========== Online/Offline Detection ==========
function updateOnlineStatus() {
    const isOnline = navigator.onLine;
    const banner = document.getElementById('offlineBanner');
    const statusIcon = document.getElementById('onlineStatusIcon');
    const statusText = document.getElementById('onlineStatusText');

    if (isOnline) {
        banner.style.display = 'none';
        statusIcon.textContent = '🟢';
        statusText.textContent = 'Online';
        // Auto-sync when connection returns
        syncPendingSales();
    } else {
        banner.style.display = 'block';
        statusIcon.textContent = '🔴';
        statusText.textContent = 'Offline';
    }
}

window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);
document.getElementById('manualSyncBtn').addEventListener('click', () => {
    if (navigator.onLine) {
        syncPendingSales();
    } else {
        alert('You are offline. Sales will be synced when connection is restored.');
    }
});

// ========== Service Worker Registration ==========
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js')
        .then(reg => console.log('Service Worker registered:', reg.scope))
        .catch(err => console.error('SW registration failed:', err));
}

// ========== Background Sync Registration (optional) ==========
async function registerBackgroundSync() {
    if ('serviceWorker' in navigator && 'SyncManager' in window) {
        const registration = await navigator.serviceWorker.ready;
        try {
            await registration.sync.register('sync-sales');
            console.log('Background sync registered');
        } catch (err) {
            console.warn('Background sync registration failed:', err);
        }
    }
}

// ========== Initialize ==========
window.addEventListener('load', async () => {
    await openDB();
    updateOnlineStatus();
    updatePendingCount();
    await registerBackgroundSync();
});

// ========== Charts ==========
const salesChart = new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{ label: 'Revenue (Ksh)', data: <?= json_encode($chart_data) ?>, borderWidth: 3, fill: true, tension: 0.4, borderColor: '#e9c46a', backgroundColor: 'rgba(233,196,106,0.1)' }]
    },
    options: { plugins: { legend: { display: false } }, responsive: true, scales: { y: { ticks: { color: '#b9c3d4' } }, x: { ticks: { color: '#b9c3d4' } } } }
});

const stockChart = new Chart(document.getElementById('stockChart'), {
    type: 'doughnut',
    data: {
        labels: ['Low Stock', 'Available'],
        datasets: [{ data: [<?= $low_stock ?>, <?= $total_products - $low_stock ?>], backgroundColor: ['#e06c4e', '#2c5f8a'] }]
    },
    options: { plugins: { legend: { position: 'bottom', labels: { color: '#b9c3d4' } } } }
});
</script>

<!-- Close the .content div and the HTML tags -->
</div> <!-- close .content -->
</body>
</html>