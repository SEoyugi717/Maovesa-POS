<?php
// ============================================================
// MAOVESA SyncPOS – Sales Terminal
// ============================================================
require_once 'config.php';       // unified DB connection
require_once 'functions.php';    // helper functions (optional for now)

// ========== Handle AJAX online checkout ==========
if (isset($_POST['checkout']) && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    header('Content-Type: application/json');
    $cart = json_decode($_POST['cart'], true);
    if (!$cart) {
        echo json_encode(['success' => false, 'error' => 'Invalid cart data']);
        exit;
    }

    $conn->beginTransaction();
    try {
        foreach ($cart as $item) {
            // Get product info
            $stmt = $conn->prepare("SELECT name, price, quantity FROM products WHERE id = ?");
            $stmt->execute([$item['id']]);
            $product = $stmt->fetch();

            if (!$product) {
                throw new Exception("Product not found: {$item['id']}");
            }
            if ($product['quantity'] < $item['qty']) {
                throw new Exception("Insufficient stock for {$product['name']}");
            }

            $total = $product['price'] * $item['qty'];
            // Insert sale
            $stmt = $conn->prepare("INSERT INTO sales (product_id, product_name, quantity, price, total, sale_date) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$item['id'], $product['name'], $item['qty'], $product['price'], $total]);
            // Update stock
            $stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
            $stmt->execute([$item['qty'], $item['id']]);
        }
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// ========== Display the page ==========
$products = $conn->query("SELECT * FROM products ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAOVESA SyncPOS | Sales Terminal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #0a0f1a;
            font-family: 'Segoe UI', system-ui;
        }
        .container-fluid {
            background: #0f141f;
            border-radius: 24px;
            padding: 20px 24px;
            margin: 20px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
        }
        .product-card {
            background: #1a1f2c;
            padding: 15px;
            border-radius: 16px;
            cursor: pointer;
            text-align: center;
            transition: 0.2s;
            border-bottom: 2px solid #e9c46a;
            color: #fff;
        }
        .product-card:hover {
            transform: scale(1.03);
            background: #252e42;
        }
        .product-card h6 { color: #e9c46a; font-weight: 600; }
        .product-card p { margin: 0; color: #b9c3d4; }
        .product-card small { color: #8a99b0; }
        .cart-box {
            background: #1a1f2c;
            padding: 20px;
            border-radius: 20px;
            color: #fff;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .cart-box h5, .cart-box h4 { color: #e9c46a; }
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            border-bottom: 1px solid #2a3448;
            padding-bottom: 8px;
        }
        .cart-item button {
            border: none;
            background: #e9c46a;
            color: #0a0f1a;
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 8px;
            margin: 0 5px;
            transition: 0.2s;
        }
        .cart-item button:hover { background: #ffd966; }
        .sync-status {
            background: #1a1f2c;
            border-radius: 40px;
            padding: 4px 12px;
            font-size: 0.8rem;
            border: 1px solid #e9c46a40;
        }
        .pending-badge {
            background: #e9c46a;
            color: #0a0f1a;
            border-radius: 30px;
            padding: 2px 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 style="font-weight:700; color:#fff;">🛒 MAOVESA SyncPOS Terminal</h3>
        <div class="sync-status">
            <span id="onlineStatusIcon">🟢</span> <span id="onlineStatusText" style="color:#fff;">Online</span>
            <span id="pendingBadge" class="pending-badge ms-2" style="display: none;">0 pending</span>
        </div>
    </div>

    <div class="row">
        <!-- PRODUCTS GRID -->
        <div class="col-lg-8">
            <div class="product-grid">
                <?php foreach ($products as $p): ?>
                    <div class="product-card"
                         onclick="addToCart(<?= $p['id'] ?>, '<?= htmlspecialchars($p['name']) ?>', <?= $p['price'] ?>)">
                        <h6><?= htmlspecialchars($p['name']) ?></h6>
                        <p>Ksh <?= number_format($p['price'], 2) ?></p>
                        <small>Stock: <?= $p['quantity'] ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- CART -->
        <div class="col-lg-4">
            <div class="cart-box">
                <h5>🧾 Cart</h5>
                <div id="cartItems"></div>
                <h4 class="mt-3">Total: Ksh <span id="total">0</span></h4>
                <button id="checkoutBtn" class="btn btn-success w-100 mt-3">Checkout</button>
                <button id="syncBtn" class="btn btn-outline-light w-100 mt-2" style="display: none;">Sync Now</button>
            </div>
        </div>
    </div>
</div>

<script>
// ========== IndexedDB (same as dashboard) ==========
const DB_NAME = 'MaovesaSyncPOS';
const DB_VERSION = 1;
const STORE_NAME = 'pending_sales';
let db = null;

function openDB() {
    return new Promise((resolve, reject) => {
        if (db) return resolve(db);
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onerror = (event) => reject(event.target.error);
        request.onsuccess = (event) => {
            db = event.target.result;
            resolve(db);
        };
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
            }
        };
    });
}

async function addSaleToQueue(saleData) {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    await store.add({ ...saleData, created_at: new Date().toISOString() });
    await tx.complete;
    updatePendingCount();
}

async function getPendingSales() {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    return await store.getAll();
}

async function removeSaleFromQueue(id) {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    await store.delete(id);
    await tx.complete;
}

async function updatePendingCount() {
    const pending = await getPendingSales();
    const badge = document.getElementById('pendingBadge');
    if (pending.length > 0) {
        badge.textContent = `${pending.length} pending`;
        badge.style.display = 'inline-block';
        document.getElementById('syncBtn').style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
        document.getElementById('syncBtn').style.display = 'none';
    }
}

// ========== Cart Management ==========
let cart = [];

function addToCart(id, name, price) {
    let item = cart.find(p => p.id === id);
    if (item) item.qty++;
    else cart.push({ id, name, price, qty: 1 });
    renderCart();
}

function renderCart() {
    let html = '';
    let total = 0;
    cart.forEach((item, idx) => {
        total += item.price * item.qty;
        html += `
        <div class="cart-item">
            <strong>${item.name}</strong>
            <div>
                <button onclick="changeQty(${idx}, -1)">-</button>
                ${item.qty}
                <button onclick="changeQty(${idx}, 1)">+</button>
            </div>
            <span>Ksh ${item.price * item.qty}</span>
        </div>
        `;
    });
    document.getElementById('cartItems').innerHTML = html;
    document.getElementById('total').innerText = total;
}

function changeQty(index, delta) {
    cart[index].qty += delta;
    if (cart[index].qty <= 0) cart.splice(index, 1);
    renderCart();
}

// ========== Checkout (online or offline) ==========
async function checkout() {
    if (cart.length === 0) {
        alert('Cart is empty');
        return;
    }

    if (!navigator.onLine) {
        // Offline: store each item as a separate pending sale
        for (const item of cart) {
            await addSaleToQueue({
                product_id: item.id,
                product_name: item.name,
                quantity: item.qty,
                total: item.price * item.qty,
                price: item.price
            });
        }
        alert('You are offline. Sale saved locally and will sync automatically when online.');
        cart = [];
        renderCart();
        return;
    }

    // Online: send via AJAX
    const checkoutBtn = document.getElementById('checkoutBtn');
    checkoutBtn.disabled = true;
    checkoutBtn.innerText = 'Processing...';

    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                checkout: 1,
                cart: JSON.stringify(cart.map(item => ({ id: item.id, qty: item.qty })))
            })
        });
        const result = await response.json();
        if (result.success) {
            alert('Sale completed successfully!');
            cart = [];
            renderCart();
        } else {
            throw new Error(result.error || 'Unknown error');
        }
    } catch (error) {
        console.error(error);
        // If online but server error, fallback to offline storage
        if (confirm('Could not process online. Save locally and sync later?')) {
            for (const item of cart) {
                await addSaleToQueue({
                    product_id: item.id,
                    product_name: item.name,
                    quantity: item.qty,
                    total: item.price * item.qty,
                    price: item.price
                });
            }
            alert('Sale saved locally. It will sync when connection is stable.');
            cart = [];
            renderCart();
        }
    } finally {
        checkoutBtn.disabled = false;
        checkoutBtn.innerText = 'Checkout';
    }
}

// ========== Manual Sync ==========
async function manualSync() {
    if (!navigator.onLine) {
        alert('You are offline. Sales will sync when connection is restored.');
        return;
    }
    const pending = await getPendingSales();
    if (pending.length === 0) {
        alert('No pending sales to sync.');
        return;
    }
    const syncBtn = document.getElementById('syncBtn');
    syncBtn.disabled = true;
    syncBtn.innerText = 'Syncing...';

    try {
        const response = await fetch('sync_sales.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sales: pending })
        });
        const result = await response.json();
        if (result.success) {
            for (const sale of pending) {
                await removeSaleFromQueue(sale.id);
            }
            alert(`Synced ${result.synced_count} sales!`);
            updatePendingCount();
        } else {
            throw new Error(result.error || 'Sync failed');
        }
    } catch (error) {
        alert('Sync failed: ' + error.message);
    } finally {
        syncBtn.disabled = false;
        syncBtn.innerText = 'Sync Now';
    }
}

// ========== Online/Offline UI ==========
function updateOnlineStatus() {
    const isOnline = navigator.onLine;
    const statusIcon = document.getElementById('onlineStatusIcon');
    const statusText = document.getElementById('onlineStatusText');
    if (isOnline) {
        statusIcon.textContent = '🟢';
        statusText.textContent = 'Online';
        // Auto-sync when coming back online
        manualSync();
    } else {
        statusIcon.textContent = '🔴';
        statusText.textContent = 'Offline';
    }
}

window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);

// ========== Initialize ==========
document.getElementById('checkoutBtn').addEventListener('click', checkout);
document.getElementById('syncBtn').addEventListener('click', manualSync);

window.addEventListener('load', async () => {
    await openDB();
    updateOnlineStatus();
    updatePendingCount();
});
</script>
</body>
</html>