<?php
/**
 * MAOVESA SyncPOS – Offline Sales Sync Endpoint
 */

// Load configuration (includes table creation and DB connection)
require_once 'config.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

header('Content-Type: application/json');

// Disable error output to avoid corrupting JSON
error_reporting(0);
ini_set('display_errors', 0);

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['sales']) || !is_array($input['sales'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid payload']);
    exit;
}

$synced_count = 0;
$errors = [];

// Process each sale in the queue
foreach ($input['sales'] as $sale) {
    // Validate required fields
    if (empty($sale['product_id']) || empty($sale['quantity']) || !isset($sale['total'])) {
        $errors[] = 'Missing required fields: ' . json_encode($sale);
        continue;
    }

    // Use the add_sale function (requires product_id, quantity)
    // Note: add_sale expects product_id and quantity only, it will fetch price and name.
    $result = add_sale($sale['product_id'], $sale['quantity']);

    if ($result) {
        $synced_count++;
    } else {
        $errors[] = 'Failed to process sale: product_id=' . $sale['product_id'] . ', quantity=' . $sale['quantity'];
    }
}

echo json_encode([
    'success' => true,
    'synced_count' => $synced_count,
    'errors' => $errors
]);